/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Controlador.Conexiones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author alumno
 */
public class PizzaDAO {

    public void insertarPizza(Pizza p) {

        Conexiones c = new Conexiones();
        Connection cn = c.conectar();
        PreparedStatement ps = null;
        ResultSet rs = null;

        int maxAco = 0;

        try {
            ps = cn.prepareStatement("select max(cod_pizza) from pizza");
            rs = ps.executeQuery();

            while (rs.next()) {
                maxAco += rs.getInt(1);
            }
            ps = cn.prepareStatement("insert into pizza values(?,?,?,?,?,?)");

            ps.setInt(1, maxAco + 1);
            ps.setString(2, p.getTipo());
            ps.setString(3, p.getTamaño());
            boolean[] ex = p.getExtras();
            for (int i = 0; i < ex.length; i++) {

                if (ex[i] == true) {
                    ps.setInt(4 + i, 1);
                } else {
                    ps.setInt(4 + i, 0);
                }

            }
            ps.executeUpdate();
            System.out.println("PIZZA INSERTADA");

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("ERROR: " + ex);
        } finally {
            try {
                c.desconexion(cn);
                ps.close();
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex);
            }
        }
    }

}
