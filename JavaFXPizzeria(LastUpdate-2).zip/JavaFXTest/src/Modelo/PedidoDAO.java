package Modelo;

import Controlador.Conexiones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

public class PedidoDAO {

    public LinkedList<Pedido> mostrarPedidos() {
        Conexiones c = new Conexiones();
        Connection cn = c.conectar();
        LinkedList<Pedido> listaPedidos = new LinkedList<Pedido>();
        Statement st = null;
        ResultSet rs = null;

        try {
            st = cn.createStatement();
            rs = st.executeQuery("select cod_pedido, tipo, tamaño, tomate,queso,piña,nombre,direccion, telefono from pizza piz, pedido ped, clientePizza c where piz.COD_PIZZA = ped.COD_PIZZA and ped.COD_CLIENTE = c.COD_CLIENTE order by cod_pedido");

            while (rs.next()) {

                String siNoTomate = "No";
                String siNoQueso = "No";
                String siNoPiña = "No";

                if (rs.getInt(4) == 1) {
                    siNoTomate = "Sí";
                }

                if (rs.getInt(5) == 1) {
                    siNoQueso = "Sí";
                }
                
                if (rs.getInt(6) == 1) {
                    siNoPiña = "Sí";
                }
                
                Pedido p = new Pedido(rs.getInt(1), rs.getString(2), rs.getString(3), siNoTomate, siNoQueso, siNoPiña, rs.getString(7), rs.getString(8), rs.getString(9));
                listaPedidos.add(p);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                st.close();
                rs.close();
                c.desconexion(cn);
            } catch (SQLException ex) {
                System.out.println("Error al desconectar: " + ex);
            }

            return listaPedidos;
        }

    }

    public void añadirPedido() {

        Conexiones c = new Conexiones();
        Connection cn = c.conectar();
        PreparedStatement ps = null;
        ResultSet rs = null;
        int maxPed = 0;
        int cod_cli = 0, cod_piz = 0;

        try {
            ps = cn.prepareStatement("select max(cod_pedido) from pedido");
            rs = ps.executeQuery();

            while (rs.next()) {
                maxPed += rs.getInt(1);
            }

            ps = cn.prepareStatement("select max(cod_cliente) from clientePizza");
            rs = ps.executeQuery();

            while (rs.next()) {
                cod_cli = rs.getInt(1);

            }

            ps = cn.prepareStatement("select max(cod_pizza) from pizza");
            rs = ps.executeQuery();

            while (rs.next()) {
                cod_piz = rs.getInt(1);

            }

            ps = cn.prepareStatement("insert into pedido values(?,?,?)");
            ps.setInt(1, maxPed + 1);
            ps.setInt(2, cod_cli);
            ps.setInt(3, cod_piz);
            ps.executeUpdate();

            System.out.println("PEDIDO INSERTADO");

            /*
            //CONSULTA PARA SACAR PEDIDO Y CLIENTE
            
            select cod_pedido, tipo, tamaño, tomate,queso,piña,nombre,direccion, telefono from pizza piz, pedido ped, clientePizza c 
            where piz.COD_PIZZA = ped.COD_PIZZA
            and ped.COD_CLIENTE = c.COD_CLIENTE 
            order by cod_pedido
             */
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("ERROR: " + ex);
        } finally {
            try {
                c.desconexion(cn);
                ps.close();
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex);
            }
        }

    }

    public int actualizarPedido(Pedido p) {

        Conexiones c = new Conexiones();
        Connection cn = c.conectar();
        PreparedStatement ps = null;

        int registrosAfectados = 0;

        try {
            ps = cn.prepareStatement("update pedido set tipo = ?, tamaño = ?, tomate = ?, queso = ?, piña = ? where cod_pedido = ?");
            ps.setString(1, p.getTipo());
            ps.setString(2, p.getTamaño());

            ps.setInt(6, p.getCod_pedido());

            registrosAfectados = ps.executeUpdate();

            System.out.println("MODIFICADO");

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex);
        } finally {
            try {
                c.desconexion(cn);
                ps.close();
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex);
            }
            return registrosAfectados;
        }
    }

    public int eliminarPedido(int indice) {

        Conexiones c = new Conexiones();
        Connection cn = c.conectar();
        PreparedStatement ps = null;

        int registrosAfectados = 0;

        try {
            ps = cn.prepareStatement("delete from pedido where cod_pedido = " + indice);

            registrosAfectados = ps.executeUpdate();

            System.out.println("ELIMINADO");

        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex);
        } finally {
            try {
                c.desconexion(cn);
                ps.close();
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex);
            }
            return registrosAfectados;
        }
    }

    
    
}
