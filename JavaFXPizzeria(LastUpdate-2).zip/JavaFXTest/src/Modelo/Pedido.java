package Modelo;

public class Pedido {

    private Cliente cliente;
    private Pizza pizza;
    
    private int cod_pedido;
    private String tipo,tamaño,nombre,direccion,telefono,tomate,queso,piña;

    public Pedido(int cod_pedido,String tipo, String tamaño,String tomate, String queso, String piña, String nombre, String direccion, String telefono) {
        this.cod_pedido = cod_pedido;
        this.tomate = tomate;
        this.queso = queso;
        this.piña = piña;
        this.tipo = tipo;
        this.tamaño = tamaño;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
    }
    
   
    public Pedido(Cliente cliente, Pizza pizza) {
        this.cliente = cliente;
        this.pizza = pizza;
    }

    public Pedido() {
    }

    @Override
    public String toString() {
        return "Pedido{" + "cliente=" + cliente + ", pizza=" + pizza + '}';
    }

    public int getCod_pedido() {
        return cod_pedido;
    }

    public void setCod_pedido(int cod_pedido) {
        this.cod_pedido = cod_pedido;
    }

    public String getTomate() {
        return tomate;
    }

    public void setTomate(String tomate) {
        this.tomate = tomate;
    }

    public String getQueso() {
        return queso;
    }

    public void setQueso(String queso) {
        this.queso = queso;
    }

    public String getPiña() {
        return piña;
    }

    public void setPiña(String piña) {
        this.piña = piña;
    }

    

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTamaño() {
        return tamaño;
    }

    public void setTamaño(String tamaño) {
        this.tamaño = tamaño;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    
}
