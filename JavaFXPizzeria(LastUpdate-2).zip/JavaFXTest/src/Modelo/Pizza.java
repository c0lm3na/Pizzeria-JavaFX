/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author alumno
 */
public class Pizza {
    
    private String tipo;
    private String tamaño;
    private boolean[] extras;
    private String extrasString;

    public Pizza(String tipo, String tamaño) {
        this.tipo = tipo;
        this.tamaño = tamaño;
        extras = new boolean[3];
    }

    public Pizza() {
        extras = new boolean[3];
    }

    @Override
    public String toString() {
        return "Pizza: " + "tipo=" + tipo + ", tama\u00f1o=" + tamaño + ", extras=";
    }
    
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTamaño() {
        return tamaño;
    }

    public void setTamaño(String tamaño) {
        this.tamaño = tamaño;
    }

    public boolean[] getExtras() {
        return extras;
    }

    public void setExtras(boolean[] extras) {
        this.extras = extras;
    }    

    public String getExtrasString() {
        return extrasString;
    }

    public void setExtrasString(String extrasString) {
        this.extrasString = extrasString;
    }
    
    
    
}
