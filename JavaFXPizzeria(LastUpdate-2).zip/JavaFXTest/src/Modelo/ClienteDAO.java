package Modelo;

import Controlador.Conexiones;
import java.sql.*;
import java.util.LinkedList;

public class ClienteDAO {
    
    public ClienteDAO() {
    }
    
    public LinkedList<Cliente> getClientes() {
        Conexiones c = new Conexiones();
        Connection cn = c.conectar();
        LinkedList<Cliente> listaClientes = new LinkedList<Cliente>();
        Statement st = null;
        ResultSet rs = null;
        
        try {
            st = cn.createStatement();
            rs = st.executeQuery("select * from clientePizza");
            
            while (rs.next()) {
                Cliente u = new Cliente(rs.getString(2), rs.getString(3), rs.getString(4));
                listaClientes.add(u);
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                st.close();
                rs.close();
                c.desconexion(cn);
            } catch (SQLException ex) {
                System.out.println("Error al desconectar: " + ex);
            }
            
            return listaClientes;
        }
        
    }
    
    public void insertarClientes(Cliente c1) {
        
        Conexiones c = new Conexiones();
        Connection cn = c.conectar();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        int maxAco = 0;
        
        try {
            ps = cn.prepareStatement("select max(cod_cliente) from clientePizza");
            rs = ps.executeQuery();
            
            while (rs.next()) {
                maxAco += rs.getInt(1);
            }
            ps = cn.prepareStatement("insert into clientePizza values(?,?,?,?)");
            
            ps.setInt(1, maxAco + 1);
            ps.setString(2, c1.getNombre());
            ps.setString(3, c1.getDireccion());
            ps.setString(4, c1.getTelefono());
            ps.executeUpdate();
            
            System.out.println("INSERTADO");
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("ERROR: " + ex);
        } finally {
            try {
                c.desconexion(cn);
                ps.close();
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex);
            }
        }
        
    }
    
    public int comprobarCliente(Cliente c1) {
        Conexiones c = new Conexiones();
        Connection cn = c.conectar();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        int registrosAfectados = 0;
        
        try {
            ps = cn.prepareStatement("select count(telefono) from clientePizza where telefono like ?");
            ps.setString(1, c1.getTelefono());
            rs = ps.executeQuery();
            
            while (rs.next()) {                
                registrosAfectados += rs.getInt(1);
            }
            
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex);
        } finally {
            try {
                c.desconexion(cn);
                ps.close();
            } catch (SQLException ex) {
                System.out.println("ERROR: " + ex);
            }
            return registrosAfectados;
        }
    }
}
