/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador;

import Controlador.FXMLDocumentController;
import Modelo.Pedido;
import Modelo.PedidoDAO;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author alumno
 */
public class FXMLModificarController implements Initializable {

    @FXML
    private Pane panelPizza;
    @FXML
    private Label tituloPizzaAModificar;
    @FXML
    private ComboBox<String> cmbTipoPizza;
    @FXML
    private RadioButton rbPequeña;
    @FXML
    private ToggleGroup Tamano;
    @FXML
    private RadioButton rbMediana;
    @FXML
    private RadioButton rbGrande;
    @FXML
    private CheckBox ckTomate;
    @FXML
    private CheckBox ckQueso;
    @FXML
    private CheckBox ckPiña;
    @FXML
    private Button btnAceptarTipo;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

        //tbCodigoPed.getCellData(tablaPedidos.getSelectionModel().getSelectedIndex())
        cmbTipoPizza.setPromptText("Tipo pizza");

        tituloPizzaAModificar.setText("P I Z Z A ");

        cmbTipoPizza.getItems().addAll("PIZZA 4 QUESOS", "BBQ", "PIZZA PIÑA");

        rbGrande.setSelected(true);

    }

    @FXML
    private void modificarPizza(ActionEvent event) {

        System.out.println("Actualizado");

    }

}
