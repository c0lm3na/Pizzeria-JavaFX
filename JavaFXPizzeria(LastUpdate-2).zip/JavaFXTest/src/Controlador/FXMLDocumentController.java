/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador;

import Modelo.Cliente;
import Modelo.ClienteDAO;
import Modelo.Pedido;
import Modelo.PedidoDAO;
import Modelo.Pizza;
import Modelo.PizzaDAO;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseButton;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author alumno
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Pane panelUsu;
    @FXML
    private Pane panelPizza;
    @FXML
    private TextField nombre;
    @FXML
    private ComboBox<String> cmbTipoPizza;
    @FXML
    private TextField direccion;
    @FXML
    private TextField telefono;
    @FXML
    private Button bttnGuardarCliente;
    @FXML
    private Button btnAceptarTipo;
    @FXML
    private RadioButton rbPequeña;
    @FXML
    private RadioButton rbMediana;
    @FXML
    private RadioButton rbGrande;
    @FXML
    private ToggleGroup Tamano;
    @FXML
    private CheckBox ckTomate;
    @FXML
    private CheckBox ckQueso;
    @FXML
    private CheckBox ckPiña;
    @FXML
    private ImageView imgPizzaTower;
    @FXML
    private ImageView imgPizzaTowerCreated;
    @FXML
    private TableColumn<Pedido, Integer> tbCodigoPed;
    @FXML
    private TableColumn<Pedido, String> tbTipo;
    @FXML
    private TableColumn<Pedido, String> tbTamaño;
    @FXML
    private TableColumn<Pedido, Integer> tbTomate;
    @FXML
    private TableColumn<Pedido, Integer> tbQueso;
    @FXML
    private TableColumn<Pedido, Integer> tbPiña;
    @FXML
    private TableColumn<Pedido, String> tbNombre;
    @FXML
    private TableColumn<Pedido, String> tbDireccion;
    @FXML
    private TableColumn<Pedido, String> tbTelefono;
    @FXML
    private TableView<Pedido> tablaPedidos;

    private Button btnAceptarPedido;
    private TableRow<Pedido> currentlySelectedRow = new TableRow<>();

    //INDICE
    private int i;

    @FXML
    private Button btnModificarPedido;
    @FXML
    private Button btnEliminarPedido;
    @FXML
    private Button bttnCrearNuevoCliente;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

        refrescarTablaSTART();

        panelPizza.setDisable(true);

        cmbTipoPizza.setPromptText("Tipo pizza");

        cmbTipoPizza.getItems().addAll("PIZZA 4 QUESOS", "BBQ", "PIZZA PIÑA");

        rbGrande.setSelected(true);
        
        nombre.setPromptText("Introduzca su nombre *");
        direccion.setPromptText("Introduzca su dirección *");
        telefono.setPromptText("Introduzca su teléfono *");

        tablaPedidos.setRowFactory(tv -> {
            TableRow<Pedido> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (!row.isEmpty() && event.getButton() == MouseButton.PRIMARY) {
                    // Colorear la fila seleccionada
                    btnModificarPedido.setDisable(false);
                    btnEliminarPedido.setDisable(false);
                    currentlySelectedRow = row;
                }
            });
            return row;
        });

        tablaPedidos.getStylesheets().add("Vista/table-view.css");
    }

    @FXML
    private void guardarCliente(ActionEvent event) {

        Alert alerta = new Alert(Alert.AlertType.INFORMATION);

        if (nombre.getText().isEmpty() || direccion.getText().isEmpty() || telefono.getText().isEmpty()) {
            alerta.setTitle("ERROR");
            alerta.setHeaderText("RELLENA TODO PORFAVOR");
            alerta.setContentText("Debe rellenar todos los datos, por favor");
            alerta.showAndWait();
        } else {
            Cliente c = new Cliente(nombre.getText(), direccion.getText(), telefono.getText());
            ClienteDAO cd = new ClienteDAO();

            if (cd.comprobarCliente(c) >= 1) {
                alerta.setTitle("CLIENTE");
                alerta.setHeaderText("ESTE CLIENTE YA EXISTE");
                alerta.setContentText("Este número de teléfono ''" + c.getTelefono() + "'' ya existe");
                alerta.showAndWait();
            } else {
                cd.insertarClientes(c);

                alerta.setTitle("INFORMACION");
                alerta.setHeaderText("Mensaje de información.");
                alerta.setContentText(c.toString());
                alerta.showAndWait();

                panelPizza.setDisable(false);
            }

        }

    }

    @FXML
    private void guardarTipoPizza(ActionEvent event) {

        String tipoPizza = cmbTipoPizza.getValue();

        Alert alerta = new Alert(Alert.AlertType.INFORMATION);

        if (cmbTipoPizza.getValue() == null) {

            alerta.setTitle("ERROR");
            alerta.setHeaderText("VALOR NULO");
            alerta.setContentText("Elige un valor de la pizza");
            alerta.showAndWait();

        } else {

            imgPizzaTower.setVisible(false);
            imgPizzaTowerCreated.setVisible(true);

            alerta.setTitle("PIZZA");
            alerta.setHeaderText("¡PIZZA CREADA!");

            RadioButton ax = (RadioButton) Tamano.getSelectedToggle();

            Pizza p = new Pizza(cmbTipoPizza.getValue(), ax.getText());
            PizzaDAO pao = new PizzaDAO();
            boolean[] a = new boolean[3];

            a[0] = ckTomate.isSelected();
            a[1] = ckQueso.isSelected();
            a[2] = ckPiña.isSelected();

            p.setExtras(a);

            pao.insertarPizza(p);

            //INSERTAR PEDIDO
            PedidoDAO ped = new PedidoDAO();

            ped.añadirPedido();

            alerta.setContentText(p.toString() + almacenarExtrasString(a));

            alerta.showAndWait();

            refrescarTabla(event);

        }

    }

    private void resetDataText() {
        nombre.setText("");
        direccion.setText("");
        telefono.setText("");

        rbGrande.setSelected(true);

        ckTomate.setSelected(false);
        ckQueso.setSelected(false);
        ckPiña.setSelected(false);

        imgPizzaTower.setVisible(true);
        imgPizzaTowerCreated.setVisible(false);

        panelPizza.setDisable(true);

    }

    private String almacenarExtrasString(boolean[] a) {
        String extrasString = "";

        if (a[0]) {
            extrasString += "Tomate";
        }
        if (a[1]) {
            extrasString += " Queso";
        }
        if (a[2]) {
            extrasString += " Piña";
        }

        for (int i = 0; i < extrasString.length(); i++) {
            if (extrasString.charAt(i) == ' ') {
                extrasString = extrasString.replace(extrasString.charAt(i), ',');
            }
        }

        return extrasString;
    }

    @FXML
    public void refrescarTabla(ActionEvent event) {

        PedidoDAO p = new PedidoDAO();
        ObservableList<Pedido> listaPedidos = FXCollections.observableArrayList(p.mostrarPedidos());

        tbCodigoPed.setCellValueFactory(new PropertyValueFactory<Pedido, Integer>("cod_pedido"));
        tbTipo.setCellValueFactory(new PropertyValueFactory<Pedido, String>("tipo"));
        tbTamaño.setCellValueFactory(new PropertyValueFactory<Pedido, String>("tamaño"));
        tbTomate.setCellValueFactory(new PropertyValueFactory<Pedido, Integer>("tomate"));
        tbQueso.setCellValueFactory(new PropertyValueFactory<Pedido, Integer>("queso"));
        tbPiña.setCellValueFactory(new PropertyValueFactory<Pedido, Integer>("piña"));
        tbNombre.setCellValueFactory(new PropertyValueFactory<Pedido, String>("nombre"));
        tbDireccion.setCellValueFactory(new PropertyValueFactory<Pedido, String>("direccion"));
        tbTelefono.setCellValueFactory(new PropertyValueFactory<Pedido, String>("telefono"));

        tablaPedidos.setItems(listaPedidos);

    }

    public void refrescarTablaSTART() {
        PedidoDAO p = new PedidoDAO();
        ObservableList<Pedido> listaPedidos = FXCollections.observableArrayList(p.mostrarPedidos());

        tbCodigoPed.setCellValueFactory(new PropertyValueFactory<Pedido, Integer>("cod_pedido"));
        tbTipo.setCellValueFactory(new PropertyValueFactory<Pedido, String>("tipo"));
        tbTamaño.setCellValueFactory(new PropertyValueFactory<Pedido, String>("tamaño"));
        tbTomate.setCellValueFactory(new PropertyValueFactory<Pedido, Integer>("tomate"));
        tbQueso.setCellValueFactory(new PropertyValueFactory<Pedido, Integer>("queso"));
        tbPiña.setCellValueFactory(new PropertyValueFactory<Pedido, Integer>("piña"));
        tbNombre.setCellValueFactory(new PropertyValueFactory<Pedido, String>("nombre"));
        tbDireccion.setCellValueFactory(new PropertyValueFactory<Pedido, String>("direccion"));
        tbTelefono.setCellValueFactory(new PropertyValueFactory<Pedido, String>("telefono"));

        tablaPedidos.setItems(listaPedidos);
    }

    private Pedido getCeldaSeleccionada() {
        if (tablaPedidos != null) {
            List<Pedido> listasSeleccionados = (List<Pedido>) tablaPedidos.getSelectionModel().getSelectedItem();

            if (listasSeleccionados.size() == 1) {
                Pedido pedidoSeleccionado = listasSeleccionados.get(0);
                System.out.println(pedidoSeleccionado);
                return pedidoSeleccionado;
            }
        }
        return null;
    }

    @FXML
    private void AceptarPedido(ActionEvent event) {
        //tablaPedidos.getStylesheets().add("Vista/table-view.css");
        //tablaPedidos.setStyle("-fx-selection-bar: green;");

        //listasSeleccionados.get(0).
        //TableRow<Pedido> row = new TableRow<>();
        if (currentlySelectedRow != null) {
            TableRow<Pedido> row = currentlySelectedRow;
            row.setStyle("-fx-background-color: greenyellow;");
            System.out.println("Aceptado");
        }
    }

    @FXML
    private void CancelarPedido(ActionEvent event) {
        if (currentlySelectedRow != null) {
            TableRow<Pedido> row = currentlySelectedRow;
            row.setStyle("-fx-background-color: null;");
            row.setStyle("-fx-font-color: black;");
            //tablaPedidos.getStylesheets().add("Vista/table-view.css");
            System.out.println("Cancelado");
        }
    }

    @FXML
    private void ModificarPedido(ActionEvent event) {

        Parent root;
        Stage stage = new Stage();

        i = tbCodigoPed.getCellData(tablaPedidos.getSelectionModel().getSelectedIndex());

        try {
            root = FXMLLoader.load(getClass().getResource("/Vista/FXMLModificar.fxml"));
            Scene scene = new Scene(root);
            stage.setTitle("PEDIDO_Nº: " + i);
            stage.setScene(scene);

            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void EliminarPedido(ActionEvent event) {

        PedidoDAO p = new PedidoDAO();

        p.eliminarPedido(currentlySelectedRow.getItem().getCod_pedido());

        refrescarTabla(event);

        if (tablaPedidos.getItems().isEmpty()) {
            btnEliminarPedido.setDisable(true);
            btnModificarPedido.setDisable(true);
        }
    }

    public TableColumn<Pedido, Integer> getTbCodigoPed() {
        return tbCodigoPed;
    }

    public TableView<Pedido> getTablaPedidos() {
        return tablaPedidos;
    }

    @FXML
    private void crearNuevoCliente(ActionEvent event) {  
        resetDataText();
    }

}
