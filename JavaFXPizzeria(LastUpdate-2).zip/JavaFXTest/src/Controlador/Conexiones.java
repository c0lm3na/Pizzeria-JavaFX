package Controlador;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexiones {

    private Connection cn;

    public Conexiones() {
    }
    
    
    public Connection conectar() {
        String url = "jdbc:oracle:thin:@localhost:1521:XE";
        String usuario = "programacion";
        String passwd = "1234";

        //CONEXION
        try {
            cn = DriverManager.getConnection(url, usuario, passwd);
            System.out.println("Conectada weon!!!");

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.err.println("ERROR: " + ex);
        }
        return cn;
    }
    
    public void desconexion(Connection c){
        
        try {
            cn.close();
            System.out.println("Desconectado.");
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error de desconexion: " + ex);
        }
        
    }

}
